import React, {useState} from "react";
import GoogleMapReact from 'google-map-react';
import {useGeolocated} from "react-geolocated";
import {useNavigate} from "react-router-dom";

const AnyReactComponent = ({ lat, lng, data }: {lat: any, lng: any, data: any}) => {
const navigate = useNavigate()
    const handleClick = () => {
        navigate(`/detail/?email=${data.email}`)
    }
    return (
    <div><img onClick={handleClick} src="https://img.icons8.com/fluency/48/000000/map-pin.png" alt='' /></div>
    )
}


export default function MapLists(mapData: any){

    const ref = React.useRef<HTMLDivElement>(null);
    const [map, setMap] = React.useState<google.maps.Map>();

    React.useEffect(() => {
        if (ref.current && !map) {
            setMap(new window.google.maps.Map(ref.current, {}));
        }
    }, [ref, map]);

    const { coords } = useGeolocated({
    positionOptions: {
      enableHighAccuracy: false,
    },
    userDecisionTimeout: 5000,
  });

    const defaultProps = {
        center: {
            lat: 0,
            lng: 0
        },
        zoom: 11
    };

    return (
        <div style={{ height: '80vh', width: '100%' }}>
            <GoogleMapReact
                bootstrapURLKeys={{ key: "" }}
                defaultCenter={defaultProps.center}
                defaultZoom={defaultProps.zoom}
            >
                {mapData.mapData.map(
                    (marker: any, index: number) => {
                        return (
                        <AnyReactComponent
                            lat={marker.lat}
                            lng={marker.lng}
                            key={index}
                            data={marker}
                        />
                        )
                    }
                )}

            </GoogleMapReact>
        </div>
    );
}
