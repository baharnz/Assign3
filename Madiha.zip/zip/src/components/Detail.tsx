import React, {useEffect, useState} from 'react';
import { useSearchParams } from "react-router-dom";




function Detail() {
    let [searchParams, setSearchParams] = useSearchParams();
    const [email, setEmail] = useState<any>('')

    useEffect(() => {
        const email1 = searchParams.get("email");
        setEmail(email1)

    })

    return (
        <div>
            <h1>Details Works for {email}</h1>
        </div>
    );
}

export default Detail;
