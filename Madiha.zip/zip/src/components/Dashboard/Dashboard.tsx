import React, {useEffect, useState} from 'react';
import MapLists from "../MapList/MapLists";
import {Col, ListGroup, Row} from "react-bootstrap";
import axios from "axios";
function getList() {

    return axios.post('http://localhost:8000/profile/list/',{

    },{
        headers:{
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
    })
        .then(function (response) {
            debugger;
            console.log(response);
            return response.data
        })
        .catch(function (error) {
            debugger;
            console.log(error);
            return false
        });
}


function Dashboard() {
    const Source = localStorage.getItem("source");
    const [lat, setLat] = useState(0);
    const [lng, setLng] = useState(0);
    const [list,setList] = useState<any[]>([])
    useEffect(() => {
        getList().then(
            res => {
                debugger;
                setList(res)
            }
        )
    })
    const ListItem = [
        {
            email: 'test@gmail.com',
            lat: 31.520370,
            lng: 74.358749
        },
        {
            email: 'test1@gmail.com',
            lat: 61.524010,
            lng: 105.318756
        },
        {
            email: 'test2@gmail.com',
            lat: 61.524010,
            lng: 100.318756
        },
        {
            email: 'test3@gmail.com',
            lat: 61.524010,
            lng: 98.318756
        },
        {
            email: 'test4@gmail.com',
            lat: 66.524010,
            lng: 91.318756
        },
        {
            email: 'test5@gmail.com',
            lat: 63.524010,
            lng: -98.318756
        },
        {
            email: 'test6@gmail.com',
            lat: 67.524010,
            lng: -90.318756
        }
    ]
    const ListData = ListItem.map(({email, lat, lng}: {email: any, lat: any, lng: any}) =>
        <li>{email}</li>
    )
    function handleClick(e: any) {
        const filter = ListItem.filter((index) => {
            return index.email === e.target.innerHTML;
        });
        setLat(filter[0].lat)
        setLng(filter[0].lng)
        console.log(lat, lng)
    }

    return (
        <div>
            <h1>Dashboard Works for {Source}</h1>
            {Source == 'fb' &&
              <Row>
                <Col md={3}>
                  <ListGroup>
                    <ListGroup.Item onClick={handleClick}>{ListData}</ListGroup.Item>
                  </ListGroup>
                </Col>
                <Col md={9}>
                  <MapLists mapData={list}></MapLists>
                </Col>
              </Row>
            }
        </div>
    );
}

export default Dashboard;
