import React from 'react';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "../components/Dashboard/Dashboard";
import Login from "../components/Login/Login";
import {default as ProtectedRoute, ProtectedRouteProps} from "./ProtectedRoute";
import MapLists from "../components/MapList/MapLists";
import {useGeolocated} from "react-geolocated";
import Detail from "../components/Detail";

function AppRoutes() {
    const defaultProtectedRouteProps: Omit<ProtectedRouteProps, 'outlet'> = {
      isAuthenticated: localStorage.getItem('token') ? true: false,
      authenticationPath: '/login',
    };
    const { coords } = useGeolocated({
        positionOptions: {
            enableHighAccuracy: false,
        },
        userDecisionTimeout: 5000,
    });
    return (
        <BrowserRouter>
            <Routes>
                <Route path='/' element={<ProtectedRoute {...defaultProtectedRouteProps} outlet={<Dashboard />} />} />
                <Route path='/detail/' element={<ProtectedRoute {...defaultProtectedRouteProps} outlet={<Detail />} />} />
                <Route path="/login" element={<Login />}  />
                <Route path="/map" element={<MapLists lat={coords?.latitude} lng={coords?.longitude} />}  />

            </Routes>
        </BrowserRouter>
    );
}


export default AppRoutes;
